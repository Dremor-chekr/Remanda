<?php
session_start();
include '../php/connecting.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../page/login.php");
  exit();
}

$userId = $_SESSION['user_id'];

// Получить историю заказов
$sql = "SELECT * FROM Orders WHERE user_id = $userId ORDER BY order_date DESC";
$result = mysqli_query($conn, $sql);
$orders = array();

while ($row = mysqli_fetch_assoc($result)) {
  $orders[] = $row;
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>История заказов</title>
  <link rel="icon" href="/img/HF.png">
  <link rel="stylesheet" type="text/css" href="../css/stele.css">
  <link rel="stylesheet" type="text/css" href="../css/preloders.css">
  <link rel="stylesheet" type="text/css" href="../css/order_history.css">
</head>
<body>
  <div id="page-preloader" class="preloder">
    <div class="loader"></div>
  </div>
  <header>
    <div class="logo">
      <h1><img class="imglogo" src="../img/HF.png" alt="HF Принтеры">История заказов</h1>
    </div>
    <nav class="Shapka">
      <ul>
        <li><a href="../index.php" class="nav-button">Главная</a></li>
        <li><a href="../page/katalog.php" class="nav-button">Каталог</a></li>
        <li><a href="../page/indormation.html" class="nav-button">О нас</a></li>
        <li><a href="../page/kontact.html" class="nav-button">Контакты</a></li>
      </ul>
    </nav>
  </header>
  <main>
    <div class="order-history">
      <h2>История ваших заказов</h2>
      <?php if (empty($orders)) { ?>
        <p>У вас пока нет заказов.</p>
      <?php } else { ?>
        <table>
          <thead>
            <tr>
              <th>Дата заказа</th>
              <th>Товар</th>
              <th>Количество</th>
              <th>Общая стоимость</th>
              <th>Адрес доставки</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $order) { ?>
              <tr>
                <td><?php echo $order['order_date']; ?></td>
                <td><?php echo $order['name']; ?></td>
                <td><?php echo $order['quantity']; ?></td>
                <td><?php echo $order['total_price']; ?>₽</td>
                <td><?php echo $order['address']; ?></td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      <?php } ?>
    </div>
  </main>
  <script src="../js/preloder.js"></script>
  <footer style="padding: 30px 0; height: auto;">
    <div style="display: flex; justify-content: space-around;">
      <div style="width: 30%;">
        <h3>Компания</h3>
        <ul>
          <li><a href="../index.php">Главная</a></li>
          <li><a href="../page/indormation.html">О нас</a></li>
          <li><a href="../page/kontact.html">Контакты</a></li>
        </ul>
      </div>
      <div style="width: 30%;">
        <h3>Следите за нами</h3>
        <ul>
          <li><img src="../img/VK.png" alt="Иконка ВК"><a href="https://vk.com/feed">VK</a></li>
          <li><img src="../img/ТГ.png" alt="Иконка Телеграм"><a href="https://web.tlgrm.app/">Телеграм</a></li>
        </ul>
      </div>
    </div>
  </footer>
</body>
</html>