<?php
session_start();
include '../php/connecting.php'; // Подключаемся к базе данных
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>HF Принтеры</title>
    <link rel="icon" href="img/HF.png">
    <link rel="stylesheet" type="text/css" href="../css/Login.css">
    <link rel="stylesheet" type="text/css" href="../css/text.css">
    <link rel="stylesheet" type="text/css" href="../css/them.css">
</head>
<body>
    <button class="theme-toggle-button" id="theme-toggle">Сменить тему</button>
    <button class="theme-toggle-button" style="top: 50px;" onclick="window.location.href='../index.php';">Вернуться на главную</button>
    <form autocomplete="off" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="typing-text" id="typing-text"></div>
        
        <label for="username">Логин:</label>
        <input type="text" id="username" name="username" required><br>

        <label for="password">Пароль:</label>
        <input type="password" id="password" name="password" autocomplete="on" required><br>

        <button type="submit">Войти</button>
    </form>

    <script src="../js/them.js"></script>
</body>
</html>

<?php
// Обработка данных после отправки формы
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if ($username === 'Manager') {
        // SQL запрос для проверки пользователя в базе данных
        $sql = "SELECT id, username, password FROM User WHERE username = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);

            // Проверка пароля
            if ($password === $row['password']) { // Если пароли хранятся в открытом виде
                $_SESSION['user_name'] = $row['username'];
                $_SESSION['user_id'] = $row['id'];
                header('Location: ../page/admin.php');
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'alert("Неправильный пароль. Попробуйте снова.");';
                echo '</script>';
            }
        } else {
            echo '<script type="text/javascript">';
            echo 'alert("Логин или пароль введены неправильно. Попробуйте снова.");';
            echo '</script>';
        }

        mysqli_stmt_close($stmt);
    } else {
        echo '<script type="text/javascript">';
        echo 'alert("Доступ ограничен только для пользователя Manager.");';
        echo '</script>';
    }
}

mysqli_close($conn);
?>
