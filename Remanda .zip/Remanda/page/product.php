<?php
include '../php/connecting.php';

$product_id = $_GET['id'];
$sql = "SELECT * FROM Catalog WHERE id = $product_id";
$result = mysqli_query($conn, $sql);
$product = mysqli_fetch_assoc($result);
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Каталог</title>
  <link rel="icon" href="/img/HF.png">
  <link rel="stylesheet" type="text/css" href="../css/stele.css">
  <link rel="stylesheet" type="text/css" href="../css/preloders.css">
  <link rel="stylesheet" type="text/css" href="../css/katalog.css">
  <link rel="stylesheet" type="text/css" href="../css/them.css">
</head> 
<body>
    <header>
        <div class="logo">
            <h1><img class="imglogo" src="../img/HF.png" alt="HF Принтеры"><?php echo $product['name']; ?></h1>
            <button class="theme-toggle-button" id="theme-toggle">Сменить тему</button>
            <button id="login-button">Войти</button>
        </div>
        <nav class="Shapka">
            <ul>
                <li><a href="../index.php" class="nav-button">Главная</a></li>
                <li><a href="../page/katalog.php" class="nav-button">Каталог</a></li>
                <li><a href="../page/indormation.html" class="nav-button">О нас</a></li>
                <li><a href="../page/kontact.html" class="nav-button">Контакты</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="kon_katalog" style="display: block; color: white;">
            <img src="<?php echo $product['img']; ?>" alt="<?php echo $product['name']; ?>">
            <h2><?php echo $product['name']; ?></h2>
            <p><?php echo $product['description']; ?></p>
            <span class="price" style="color: white;"><?php echo $product['price']; ?>₽</span>
            <button type="submit" class="buy-button add-to-cart-button">В корзину</button>
        </div>
    </main>
    <footer style="padding: 30px 0; height: auto;">
        <div style="display: flex; justify-content: space-around;">
            <div style="width: 30%;">
                <h3>Компания</h3>
                <ul>
                    <li><a href="../page/page.html">Главная</a></li>
                    <li><a href="../page/indormation.html">О нас</a></li>
                    <li><a href="../page/kontact.html">Контакты</a></li>
                </ul>
            </div>
            <div style="width: 30%;">
                <h3>Следите за нами</h3>
                <ul>
                    <li><img src="../img/VK.png" alt="Иконка ВК"><a href="https://vk.com/feed">VK</a></li>
                    <li><img src="../img/ТГ.png" alt="Иконка Телеграм"><a href="https://web.tlgrm.app/">Телеграм</a></li>
                </ul>
            </div>
        </div>
    </footer>
    <script src="../js/preloder.js"></script>
    <script src="../js/login_button.js"></script>
    <script src="../js/them.js"></script>
</body>
</html>
