<?php
session_start(); // Начало сессии
include '../php/connecting.php'; // Подключаемся к базе данных

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получаем данные из формы
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Валидация данных
    if (empty($username) || empty($password) || empty($confirm_password)) {
        die('Please fill in all fields.');
    }

    if ($password !== $confirm_password) {
        die('Passwords do not match.');
    }

    // Проверка на существующего пользователя
    $query = "SELECT id FROM User WHERE username = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("s", $username);
    if ($stmt->execute() === false) {
        die('Error executing the query: ' . htmlspecialchars($stmt->error));
    }
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo '<script type="text/javascript">';
        echo 'alert("Такой пользователь уже существует попробуйте ещё раз");';
        echo '</script>';
    }

    // Вставка нового пользователя в базу данных
    $query = "INSERT INTO User (username, password) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Error preparing the query: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("ss", $username, $password);
    if ($stmt->execute() === false) {
        die('Error executing the query: ' . htmlspecialchars($stmt->error));
    }

    // Перенаправление на страницу входа или главную страницу после успешной регистрации
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - HF Принтеры</title>
    <link rel="icon" href="img/HF.png">
    <link rel="stylesheet" type="text/css" href="../css/Login.css">
    <link rel="stylesheet" type="text/css" href="../css/text.css">
    <link rel="stylesheet" type="text/css" href="../css/them.css">
</head>
<body>
    <button class="theme-toggle-button" id="theme-toggle">Сменить тему</button>
    <button class="theme-toggle-button" style="top: 50px;" onclick="window.location.href='../page/login.php';">Вернуться к авторизации</button>
    <form action="register.php" method="post">
            <label for="username">Логин</label>
            <input type="text" id="username" name="username" required>
            
            <label for="password">Пароль</label>
            <input type="password" id="password" name="password" required>
            
            <label for="confirm_password">Повторение пароля</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
            
            <button type="submit">Register</button>
        </form>
    <script src="../js/them.js"></script>
</body>
</html>
