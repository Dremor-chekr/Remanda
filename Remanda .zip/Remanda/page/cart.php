<?php
session_start();
include '../php/connecting.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../page/login.php");
  exit();
}

$userId = $_SESSION['user_id'];

// Получить товары из корзины
$sql = "SELECT * FROM Basket WHERE id_user = $userId";
$result = mysqli_query($conn, $sql);
$cartItems = array();

while ($row = mysqli_fetch_assoc($result)){
  $cartItems[] = $row;
}

// Подсчет общей стоимости
$totalPrice = 0;
foreach ($cartItems as $item) {
  $totalPrice += $item['price'] * $item['quantity'];
}

// Получить данные из таблицы place_of_issue
$placesSql = "SELECT name FROM place_of_issue";
$placesResult = mysqli_query($conn, $placesSql);
$places = array();

while ($row = mysqli_fetch_assoc($placesResult)) {
  $places[] = $row['name'];
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Корзина</title>
  <link rel="icon" href="/img/HF.png">
  <link rel="stylesheet" type="text/css" href="../css/stele.css">
  <link rel="stylesheet" type="text/css" href="../css/preloders.css">
  <link rel="stylesheet" type="text/css" href="../css/katalog.css">
  <link rel="stylesheet" type="text/css" href="../css/them.css">

</head> 
<body>
  <div id="page-preloader" class="preloder">
    <div class="loader"></div>
  </div>
  <header>
    <div class="logo">
      <h1><img class="imglogo" src="../img/HF.png" alt="HF Принтеры">Корзина</h1>
    </div>
    <nav class="Shapka">
      <ul>
        <li><a href="../index.php" class="nav-button">Главная</a></li>
        <li><a href="../page/katalog.php" class="nav-button">Каталог</a></li>
        <li><a href="../page/indormation.html" class="nav-button">О нас</a></li>
        <li><a href="../page/kontact.html" class="nav-button">Контакты</a></li>
        <li><a href="../page/users.php" class="nav-button">Личный кабинет</a></li>
      </ul>
    </nav>
  </header>
  <main>
    <div class="logo">
      <button class="theme-toggle-button" id="theme-toggle">Сменить тему</button>
      <button id="login-button">Войти</button>
    </div>
    <div id="main">
      <h2>Ваша корзина</h2>
      <?php if (empty($cartItems)) { ?>
        <p>Ваша корзина пуста.</p>
      <?php } else { ?>
        <div class="kon_katalog"  style="background-color: #ffffff00">
          <table>
            <thead>
              <tr>
                <th>Товар</th>
                <th>Цена</th>
                <th>Количество</th>
                <th>Общая стоимость</th>
                <th>Удалить</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($cartItems as $item) { ?>
              <tr>
                <td><img src="<?php echo $item['img']; ?>"><?php echo $item['name']; ?></td>
                <td><?php echo $item['price']; ?>₽</td>
                <td>
                  <button class="decrement" data-product-id="<?php echo $item['id']; ?>">-</button>
                  <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1" class="quantity-input" data-product-id="<?php echo $item['id']; ?>">
                  <button class="increment" data-product-id="<?php echo $item['id']; ?>">+</button>
                </td>
                <td class="total-price"><?php echo $item['price'] * $item['quantity']; ?>₽</td>
                <td>
                  <form method="post" action="../php/remove_from_cart.php" style="background-color: #ffffff00">
                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                    <button type="submit">Удалить</button>
                  </form>
                </td>
              </tr>
              <?php } ?>
            </tbody>
          </table>
          
          <form method="post" action="../php/checkout.php" style="background-color: #ffffff00">
            <label for="address">Адрес доставки:</label>
            <select name="address" required>
              <?php foreach ($places as $place) { ?>
                <option value="<?php echo $place; ?>"><?php echo $place; ?></option>
              <?php } ?>
            </select>
            <p>Общая стоимость: <span id="total-price"><?php echo $totalPrice; ?></span>₽</p>
            <button type="submit">Оформить заказ</button>
          </form>
        </div>
      <?php } ?>
    </div>
  </main>
  <script src="../js/preloder.js"></script>
  <footer style="padding: 30px 0; height: auto;">
    <div style="display: flex; justify-content: space-around;">
      <div style="width: 30%;">
        <h3>Компания</h3>
        <ul>
          <li><a href="../index.php">Главная</a></li>
          <li><a href="../page/indormation.html">О нас</a></li>
          <li><a href="../page/kontact.html">Контакты</a></li>
        </ul>
      </div>
      <div style="width: 30%;">
        <h3>Следите за нами</h3>
        <ul>
          <li><img src="../img/VK.png" alt="Иконка ВК"><a href="https://vk.com/feed">VK</a></li>
          <li><img src="../img/ТГ.png" alt="Иконка Телеграм"><a href="https://web.tlgrm.app/">Телеграм</a></li>
        </ul>
      </div>
    </div>
  </footer>
  <script src="../js/login_button.js"></script>
  <script src="../js/them.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      document.querySelectorAll('.increment').forEach(button => {
        button.addEventListener('click', function () {
          updateQuantity(this.dataset.productId, 1);
        });
      });

      document.querySelectorAll('.decrement').forEach(button => {
        button.addEventListener('click', function () {
          updateQuantity(this.dataset.productId, -1);
        });
      });

      document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('change', function () {
          const newQuantity = parseInt(this.value);
          updateQuantity(this.dataset.productId, newQuantity - parseInt(this.dataset.previousValue));
        });
        input.addEventListener('focus', function () {
          this.dataset.previousValue = this.value;
        });
      });

      function updateQuantity(productId, change) {
        const input = document.querySelector(`.quantity-input[data-product-id='${productId}']`);
        let newQuantity = parseInt(input.value) + change;
        if (newQuantity < 1) newQuantity = 1;

        const formData = new FormData();
        formData.append('product_id', productId);
        formData.append('quantity', newQuantity);

        fetch('../php/update_quantity.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            input.value = data.quantity;
            updateTotalPrice(productId, data.quantity);
            updateOverallTotal();
          } else {
            console.error(data.message);
          }
        })
        .catch(error => console.error('Error:', error));
      }

      function updateTotalPrice(productId, quantity) {
        const row = document.querySelector(`button[data-product-id='${productId}']`).closest('tr');
        const price = parseInt(row.querySelector('td:nth-child(2)').textContent.replace('₽', ''));
        row.querySelector('.total-price').textContent = (price * quantity) + '₽';
      }

      function updateOverallTotal() {
        let overallTotal = 0;
        document.querySelectorAll('tr').forEach(row => {
          const priceElement = row.querySelector('.total-price');
          if (priceElement) {
            overallTotal += parseInt(priceElement.textContent.replace('₽', ''));
          }
        });
        const totalPriceElement = document.getElementById('total-price');
        totalPriceElement.textContent = overallTotal;
      }
    });
  </script>
</body>
</html>
