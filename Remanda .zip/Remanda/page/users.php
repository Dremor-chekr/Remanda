<?php
include '../php/connecting.php'; 
session_start();

// Проверка, если пользователь не авторизован, перенаправить на страницу входа
if (!isset($_SESSION['user_id'])) {
    header('Location: ../page/login.php');
    exit;
}
$user_id = $_SESSION['user_id'];

// Если форма отправлена, обновляем данные профиля
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $birthday = $_POST['birthday'];
    $city = $_POST['city'];
    $phone = $_POST['phone'];
    $avatar = $_POST['avatar'];

    $update_query = "UPDATE UserProfile SET name=?, birthday=?, city=?, phone=?, avatar=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "sssssi", $name, $birthday, $city, $phone, $avatar, $user_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

// Создаем запрос для получения данных профиля
$query = "SELECT u.username, up.name, up.birthday, up.city, up.phone, up.avatar
          FROM User u
          JOIN UserProfile up ON u.id = up.id
          WHERE u.id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Выводим данные профиля в форме
if ($row = mysqli_fetch_assoc($result)) {
    $username = htmlspecialchars($row['username']);
    $name = htmlspecialchars($row['name']);
    $birthday = htmlspecialchars($row['birthday']);
    $city = htmlspecialchars($row['city']);
    $phone = htmlspecialchars($row['phone']);
    $avatar = htmlspecialchars($row['avatar']);
} else {
    // Обработка ситуации, если пользователь не найден
}

if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit();
}

$userId = $_SESSION['user_id'];

// Получить историю заказов
$sql = "SELECT * FROM Orders WHERE user_id = ? ORDER BY order_date DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $userId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$orders = array();

while ($row = mysqli_fetch_assoc($result)) {
    $orders[] = $row;
}

mysqli_stmt_close($stmt);
mysqli_close($conn);

// Группировка заказов по дате
$grouped_orders = [];
foreach ($orders as $order) {
    $date = date('Y-m-d', strtotime($order['order_date']));
    $grouped_orders[$date][] = $order;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>HF Принтеры - Личный кабинет</title>
    <link rel="icon" href="/img/HF.png">
    <link rel="stylesheet" type="text/css" href="../css/users.css">
    <link rel="stylesheet" href="../css/stele.css">
    <link rel="stylesheet" href="../css/page_print.css">
    <link rel="stylesheet" type="text/css" href="../css/preloders.css">
    <link rel="stylesheet" type="text/css" href="../css/them.css">
    <style>
          .highlight-table {
    border: 2px solid lightblue;
    animation: glow 1.5s infinite alternate;
}

@keyframes glow {
    0% {
        box-shadow: 0 0 5px lightblue;
    }
    100% {
        box-shadow: 0 0 20px lightblue;
    }
}
    </style>
</head>
<body>
<div id="page-preloader" class="preloder">
    <div class="loader"></div>
</div>
<header>
    <div class="logo">
        <h1><img class="imglogo" src="../img/HF.png" alt="HF Принтеры">HF Принтеры</h1>
        <button class="theme-toggle-button" id="theme-toggle">Сменить тему</button>
        <form method="post" action="../php/logout.php" style="display:inline;">
            <button class="theme-toggle-button" style="top: 50px" type="submit">Выйти</button>
          </form>
    </div>
    <nav class="Shapka">
        <ul>
            <li><a href="../index.php" class="nav-button">Главная</a></li>
            <li><a href="../page/katalog.php" class="nav-button">Каталог</a></li>
            <li><a href="../page/indormation.html" class="nav-button">О нас</a></li>
            <li><a href="../page/kontact.html" class="nav-button">Контакты</a></li>
            <li><a href="../page/users.php" class="nav-button">Личный кабинет</a></li>
        </ul>
    </nav>
</header>
<main id="main">
    <h1>Профиль пользователя</h1>
    <div class="avatar-container">
      <?php if ($avatar): ?>
        <img src="<?php echo $avatar; ?>" alt="Avatar">
      <?php endif; ?>
    </div>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <label for="avatar">Аватар (URL):</label>
      <input type="text" id="avatar" name="avatar" value="<?php echo $avatar; ?>">

      <label for="name">Имя:</label>
      <input type="text" id="name" name="name" value="<?php echo $name; ?>">

      <label for="birthday">Дата рождения:</label>
      <input type="date" id="birthday" name="birthday" value="<?php echo $birthday; ?>">

      <label for="city">Город:</label>
      <input type="text" id="city" name="city" value="<?php echo $city; ?>">

      <label for="phone">Телефон:</label>
      <input type="text" id="phone" name="phone" value="<?php echo $phone; ?>">

      <input type="submit" value="Сохранить изменения">
    </form>

    <div class="order-history">
    <h2>История ваших заказов</h2>
    <?php if (empty($orders)) { ?>
        <p>У вас пока нет заказов.</p>
    <?php } else { ?>
        <?php // Преобразование массива $grouped_orders для сортировки по дате и времени
        $sorted_orders = [];
        foreach ($grouped_orders as $date => $orders) {
            foreach ($orders as $order) {
                // Используем дату и время заказа в качестве ключа для сортировки
                $datetime = $order['order_date']; // Это должна быть полная строка с датой и временем
                $sorted_orders[$datetime][] = $order;
            }
        }
        krsort($sorted_orders); // Сортировка по убыванию времени (новые заказы сначала)
        ?>
        
        <?php $first_iteration = true; ?>
        <?php foreach ($sorted_orders as $datetime => $orders) { ?>
            <?php $formatted_date = date('d.m.Y H:i', strtotime($datetime)); ?>
            
            <div class="order-group">
                <h3>Заказы от <?php echo $formatted_date; ?></h3>

                <table <?php if ($first_iteration) { echo 'class="highlight-table"'; $first_iteration = false; } ?>>
                    <thead>
                        <tr>
                            <th>Фото товара</th>
                            <th>Дата заказа</th>
                            <th>Товар</th>
                            <th>Количество</th>
                            <th>Общая стоимость</th>
                            <th>Адрес доставки</th>
                            <th>Статус заказа</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order) { ?>
                            <tr>
                                <td><img src="<?php echo $order['img']; ?>" alt="Картинка товара"></td>
                                <td><?php echo $order['order_date']; ?></td>
                                <td><?php echo $order['name']; ?></td>
                                <td><?php echo $order['quantity']; ?></td>
                                <td><?php echo $order['total_price']; ?>₽</td>
                                <td><?php echo $order['address']; ?></td>
                                <td><?php echo $order['status']; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
                
            </div>
        <?php } ?>
    <?php } ?>
</div>

  </main>
<footer>
    <div style="display: flex; justify-content: space-around;">
        <div style="width: 30%;">
            <h3>Компания</h3>
            <ul>
                <li><a href="../page/katalog.php">Каталог</a></li>
                <li><a href="../page/indormation.html">О нас</a></li>
                <li><a href="../page/kontact.html">Контакты</a></li>
            </ul>
        </div>
        <div style="width: 30%;">
            <div>
                <h3>Следите за нами</h3>
                <ul>
                    <li><img src="../img/VK.png" alt="Иконка ВК"><a href="https://vk.com/feed">VK</a></li>
                    <li><img src="../img/ТГ.png" alt="Иконка Телеграм"><a href="https://web.tlgrm.app/">Телеграм</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<script src="../js/preloder.js"></script>
<script src="../js/them.js"></script>
<script src="../js/logout_button.js"></script>
</body>
</html>