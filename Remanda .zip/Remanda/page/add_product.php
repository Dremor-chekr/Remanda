<?php
include '../php/connecting.php'; 
session_start();

// Проверка, если пользователь не авторизован, перенаправить на страницу входа
if (!isset($_SESSION['user_id']) || $_SESSION['user_name'] !== 'Manager') {
  header('Location: ../page/adminlog.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $name = $_POST['name'];
  $img = $_POST['img'];
  $price = $_POST['price'];
  $description = $_POST['description'];
  $type = $_POST['type'];
  $category = $_POST['category'];

  $sql = "INSERT INTO Catalog (name, img, price, description, type, category) VALUES (?, ?, ?, ?, ?, ?)";
  $stmt = mysqli_prepare($conn, $sql);
  mysqli_stmt_bind_param($stmt, 'ssdsss', $name, $img, $price, $description, $type, $category);

  if (mysqli_stmt_execute($stmt)) {
    echo "Товар успешно добавлен.";
  } else {
    echo "Ошибка: " . mysqli_error($conn);
  }

  mysqli_stmt_close($stmt);
  mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>HF Принтеры - Управление заказами</title>
  <link rel="icon" href="../img/HF.png">
  <link rel="stylesheet" href="../css/stele.css">
  <link rel="stylesheet" type="text/css" href="/css/preloders.css">
  <link rel="stylesheet" href="../css/page_print.css">
  
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      margin: 0;
      padding: 0;
    }
    header {
      background-color: rgb(28, 51, 53);
      color: black;
      padding: 10px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .admin-panel {
      background-color: #fff;
      padding: 20px;
      margin: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .admin-panel h2 {
      margin-bottom: 20px;
    }
    .orders-table {
      width: 100%;
      border-collapse: collapse;
    }
    .orders-table th, .orders-table td {
      border: 1px solid #ddd;
      padding: 8px;
      text-align: center;
    }
    .orders-table th {
      background-color: #f2f2f2;
    }
    .orders-table td form {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .orders-table td select {
      padding: 6px;
      font-size: 14px;
    }
    .orders-table td button {
      padding: 6px 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      cursor: pointer;
      border-radius: 4px;
    }
    .orders-table td button:hover {
      background-color: #45a049;
    }
    footer {
      background-color: rgb(28, 51, 53);
      color: #fff;
      padding: 20px 0;
      text-align: center;
    }
    footer ul {
      list-style-type: none;
      padding: 0;
    }
    footer ul li {
      display: inline;
      margin: 0 10px;
    }
    footer ul li a {
      color: #fff;
      text-decoration: none;
    }
    .theme-toggle-button {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 10px;
    border-radius: 5px;
    background-color: white;
    color: black;
    border: none;
    cursor: pointer;
}
  </style>
</head>
<body>
    <header >
        
        <h1>Добавить новый товар</h1> 
        <button class="theme-toggle-button" style="top: 50px;" onclick="window.location.href='../page/admin.php';">Вернутся на главную страницу админки</button>
        
    </header>
    
    
    <main>
      
    <form method="post" action="add_product.php">
      <label for="name">Название товара:</label><br>
      <input type="text" id="name" name="name" required><br>
      
      <label for="img">URL изображения:</label><br>
      <input type="text" id="img" name="img" required><br>
      
      <label for="price">Цена:</label><br>
      <input type="number" id="price" name="price" step="0.01" required><br>
      
      <label for="description">Описание:</label><br>
      <textarea id="description" name="description" required></textarea><br>
      
      <label for="type">Тип:</label><br>
      <input type="text" id="type" name="type" required><br>
      
      <label for="category">Категория:</label><br>
      <input type="text" id="category" name="category" required><br>
      
      <button type="submit">Добавить товар</button>
    </form>
  </main>
</body>
</html>
