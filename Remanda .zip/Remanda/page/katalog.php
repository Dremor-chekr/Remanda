<?php 
session_start();
include '../php/connecting.php'; 

$sql = "SELECT * FROM `Catalog`";
$result = mysqli_query($conn, $sql);
$products = array();

while ($row = mysqli_fetch_assoc($result)){
  $products[] = $row;
}
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Каталог</title>
  <link rel="icon" href="/img/HF.png">
  <link rel="stylesheet" type="text/css" href="../css/stele.css">
  
  <link rel="stylesheet" type="text/css" href="../css/katalog.css">
  <link rel="stylesheet" type="text/css" href="../css/them.css">
</head> 
<body>
  <div id="page-preloader" class="preloder">
    <div class="loader"></div>
  </div>
  <header>
    <div class="logo">
      <h1><img class="imglogo" src="../img/HF.png" alt="HF Принтеры">Каталог</h1>
      <button class="theme-toggle-button" id="theme-toggle">Сменить тему</button>
      <button id="login-button">Войти</button>
      <button class="theme-toggle-button" style="top: 90px;"><a href="../page/cart.php">Корзина</a></button>
    </div>
    <nav class="Shapka">
      <ul>
        <li><a href="../index.php" class="nav-button">Главная</a></li>
        <li><a href="../page/katalog.php" class="nav-button">Каталог</a></li>
        <li><a href="../page/indormation.html" class="nav-button">О нас</a></li>
        <li><a href="../page/kontact.html" class="nav-button">Контакты</a></li>
        <li><a href="../page/users.php" class="nav-button">Личный кабинет</a></li>
      </ul>
    </nav>
  </header>
  <main >
    <div class="header">
      <div class="kon_katalog" id="main">
      <div class="serch">
  <input type="text" id="search-box" placeholder="Поиск по каталогу">
  <button id="search-button">Поиск</button>
  <div>
    <label>
      <input type="checkbox" id="filter-mfu"> МФУ
    </label>
    <label>
      <input type="checkbox" id="filter-laser"> Лазерные
    </label>
    <label>
      <input type="checkbox" id="filter-inkjet"> Струйные
    </label>
  </div>
  <!-- Скрипт поиска и фильтрации -->
  <script>
    const products = <?php echo json_encode($products); ?>;
    document.getElementById('search-button').addEventListener('click', function() {
      filterAndDisplayProducts();
    });
    document.getElementById('search-box').addEventListener('keydown', function(event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        filterAndDisplayProducts();
      }
    });
    document.getElementById('filter-mfu').addEventListener('change', filterAndDisplayProducts);
    document.getElementById('filter-laser').addEventListener('change', filterAndDisplayProducts);
    document.getElementById('filter-inkjet').addEventListener('change', filterAndDisplayProducts);

    function filterAndDisplayProducts() {
      const searchBox = document.getElementById('search-box');
      const searchQuery = searchBox.value.trim().toLowerCase();
      const filterMFU = document.getElementById('filter-mfu').checked;
      const filterLaser = document.getElementById('filter-laser').checked;
      const filterInkjet = document.getElementById('filter-inkjet').checked;

      const filteredProducts = filterProducts(products, searchQuery, filterMFU, filterLaser, filterInkjet);
      const productsList = document.getElementById('products');
      productsList.innerHTML = '';
      filteredProducts.forEach(product => {
        const productHTML = `
          <div class="product">
            <h2>${product.name}</h2>
            <a href="../page/product.php?id=${product.id}">
              <img src="${product.img}">
            </a>
            <span class="price">${product.price}₽</span>
            <form method="post" action="../php/add_to_cart.php">
              <input type="hidden" name="product_id" value="${product.id}">
              <button type="submit" class="buy-button add-to-cart-button">В корзину</button>
            </form>
          </div>`;
        productsList.innerHTML += productHTML;
      });
    }

    function filterProducts(products, query, filterMFU, filterLaser, filterInkjet) {
      return products.filter(product => {
        const matchesQuery = product.name.toLowerCase().includes(query);
        const matchesMFU = filterMFU ? product.type.toLowerCase().includes('мфу') : true;
        const matchesLaser = filterLaser ? product.category.toLowerCase().includes('лазерный') : true;
        const matchesInkjet = filterInkjet ? product.category.toLowerCase().includes('струйный') : true;
        return matchesQuery && matchesMFU && matchesLaser && matchesInkjet;
      });
    }
  </script>
</div>
        <div id="products">
          <?php foreach ($products as $product) {?>
            <div class="product">
              <h2  style="color: #ffffff"><?php echo $product['name'];?></h2>
              <a href="../page/product.php?id=<?php echo $product['id']; ?>">  
                <img src="<?php echo $product['img']; ?>">
              </a>
              <span class="price" style="color: #ffffff"><?php echo $product['price'];?>₽</span>
              <form method="post" action="../php/add_to_cart.php" style="background-color: #ffffff00">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                <button type="submit" class="buy-button add-to-cart-button">В корзину</button>
              </form>
            </div>
          <?php }?>
        </div>
      </div>
    </main>
    
    <footer style="padding: 30px 0; height: auto;">
      <div style="display: flex; justify-content: space-around;">
        <div style="width: 30%;">
          <h3>Компания</h3>
          <ul>
            <li><a href="../index.php">Главная</a></li>
            <li><a href="../page/indormation.html">О нас</a></li>
            <li><a href="../page/kontact.html">Контакты</a></li>
          </ul>
        </div>
        <div style="width: 30%;">
          <h3>Следите за нами</h3>
          <ul>
            <li><img src="../img/VK.png" alt="Иконка ВК"><a href="https://vk.com/feed">VK</a></li>
            <li><img src="../img/ТГ.png" alt="Иконка Телеграм"><a href="https://web.tlgrm.app/">Телеграм</a></li>
          </ul>
        </div>
      </div>
    </footer>
    <script src="../js/login_button.js"></script>
    <script src="../js/them.js"></script>
  </body>
</html>
