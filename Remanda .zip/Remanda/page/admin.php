<?php
include '../php/connecting.php'; 
session_start();

// Проверка, если пользователь не авторизован, перенаправить на страницу входа
if (!isset($_SESSION['user_id']) || $_SESSION['user_name'] !== 'Manager') {
  header('Location: ../page/adminlog.php');
  exit;
}

// Получение всех заказов из базы данных
$sql = "SELECT * FROM Orders";
$result = mysqli_query($conn, $sql);
$orders = mysqli_fetch_all($result, MYSQLI_ASSOC);
mysqli_free_result($result);
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>HF Принтеры - Управление заказами</title>
  <link rel="icon" href="../img/HF.png">
  <link rel="stylesheet" href="../css/stele.css">
  <link rel="stylesheet" type="text/css" href="/css/preloders.css">
  <link rel="stylesheet" href="../css/page_print.css">
  
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
      margin: 0;
      padding: 0;
    }
    header {
      background-color: rgb(28, 51, 53);
      color: black;
      padding: 10px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .admin-panel {
      background-color: #fff;
      padding: 20px;
      margin: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .admin-panel h2 {
      margin-bottom: 20px;
    }
    .orders-table {
      width: 100%;
      border-collapse: collapse;
    }
    .orders-table th, .orders-table td {
      border: 1px solid #ddd;
      padding: 8px;
      text-align: center;
    }
    .orders-table th {
      background-color: #f2f2f2;
    }
    .orders-table td form {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .orders-table td select {
      padding: 6px;
      font-size: 14px;
    }
    .orders-table td button {
      padding: 6px 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      cursor: pointer;
      border-radius: 4px;
    }
    .orders-table td button:hover {
      background-color: #45a049;
    }
    footer {
      background-color: rgb(28, 51, 53);
      color: #fff;
      padding: 20px 0;
      text-align: center;
    }
    footer ul {
      list-style-type: none;
      padding: 0;
    }
    footer ul li {
      display: inline;
      margin: 0 10px;
    }
    footer ul li a {
      color: #fff;
      text-decoration: none;
    }
    .theme-toggle-button {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 10px;
    border-radius: 5px;
    background-color: white;
    color: black;
    border: none;
    cursor: pointer;
}
  </style>
</head>
<body>
  <header>
    <div class="logo">
      <h1><img class="imglogo" src="/img/HF.png" alt="HF Принтеры">HF Принтеры</h1>
    </div>
    <form method="post" action="../php/logout.php" style="display:inline;">
            <button class="theme-toggle-button" style="top: 50px" type="submit">Выйти</button>
          </form>
          <br>
    <button class="theme-toggle-button" style="top: 90px;" onclick="window.location.href='../index.php';">Вернуться на главную</button>
    <br>
    <button class="theme-toggle-button" onclick="window.location.href='add_product.php';">Добавить новый товар</button>
    <br>
  </header>
  
  <main id="main" style="padding: 20px;">
    <div class="admin-panel">
      <h2>Управление заказами</h2>
      <table class="orders-table">
        <thead>
          <tr>
            <th>ID Заказа</th>
            <th>Дата заказа</th>
            <th>Товар</th>
            <th>Количество</th>
            <th>Общая стоимость</th>
            <th>Статус</th>
            <th>Изменить статус</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($orders as $order): ?>
            <tr>
              <td><?php echo $order['order_id']; ?></td>
              <td><?php echo $order['order_date']; ?></td>
              <td><?php echo $order['name']; ?></td>
              <td><?php echo $order['quantity']; ?></td>
              <td><?php echo $order['total_price']; ?>₽</td>
              <td><?php echo $order['status']; ?></td>
              <td>
                <form method="post" action="../php/update_order_status.php">
                  <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                  <select name="new_status">
                    <option value="В обработке">В обработке</option>
                    <option value="Доставляется">Доставляется</option>
                    <option value="Доставлен">Доставлен</option>
                  </select>
                  <button type="submit">Изменить</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
  
  <footer>
    <ul>
      <li><a href="../page/katalog.php">Каталог</a></li>
      <li><a href="../page/indormation.html">О нас</a></li>
      <li><a href="../page/kontact.html">Контакты</a></li>
    </ul>
    <div>
      <h3>Следите за нами</h3>
      <ul>
        <li><img src="/img/VK.png" alt="Иконка ВК"><a href="https://vk.com/feed">VK</a></li>
        <li><img src="/img/ТГ.png" alt="Иконка Телеграм"><a href="https://web.tlgrm.app/">Телеграм</a></li>
      </ul>
    </div>
  </footer>
  
  <script src="../js/preloder.js"></script>
  <script src="../js/adminpanel.js"></script>
  <script src="../js/them.js"></script>
  <script src="../js/login_button.js"></script>
</body>
</html>
