<?php
session_start();
include '../php/connecting.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../page/login.php");
  exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $productId = $_POST['product_id'];
  $userId = $_SESSION['user_id'];

  // Получить информацию о продукте из таблицы Catalog
  $sql = "SELECT * FROM Catalog WHERE id = $productId";
  $result = mysqli_query($conn, $sql);
  $product = mysqli_fetch_assoc($result);

  // Проверить, если продукт найден
  if ($product) {
    $name = $product['name'];
    $img = $product['img'];
    $price = $product['price'];
    $quantity = 1;  // Количество по умолчанию
    $address = '';  // Можно добавить адрес, если он есть

    // Проверить, если продукт уже в корзине
    $checkSql = "SELECT * FROM Basket WHERE id = $productId AND id_user = $userId";
    $checkResult = mysqli_query($conn, $checkSql);
    if (mysqli_num_rows($checkResult) > 0) {
      // Обновить количество, если продукт уже в корзине
      $updateSql = "UPDATE Basket SET quantity = quantity + 1 WHERE id = $productId AND id_user = $userId";
      mysqli_query($conn, $updateSql);
    } else {
      // Вставить продукт в корзину
      $insertSql = "INSERT INTO Basket (id, id_user, name, img, price, quantity, address) 
                    VALUES ($productId, $userId, '$name', '$img', $price, $quantity, '$address')";
      mysqli_query($conn, $insertSql);
    }

    // Перенаправление на страницу корзины
    header("Location: ../page/katalog.php");
    exit();
  } else {
    echo "Продукт не найден.";
  }

  mysqli_close($conn);
}
?>
