<?php
// Подключение к базе данных
include '../php/connecting.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получение данных из формы
    $order_id = $_POST['order_id'];
    $new_status = $_POST['new_status'];
    
    // Подготовка запроса на обновление статуса заказа
    $sql = "UPDATE Orders SET status = ? WHERE order_id = ?";
    
    // Подготовка выражения запроса
    $stmt = mysqli_prepare($conn, $sql);
    
    // Привязка параметров
    mysqli_stmt_bind_param($stmt, "si", $new_status, $order_id);
    
    // Выполнение запроса
    if (mysqli_stmt_execute($stmt)) {
        // Успешное обновление
        echo "Статус заказа успешно обновлен.";
    } else {
        // Ошибка при выполнении запроса
        echo "Ошибка при обновлении статуса заказа: " . mysqli_error($conn);
    }
    
    // Закрытие выражения запроса
    mysqli_stmt_close($stmt);
}
header('Location: ../page/admin.php');

// Закрытие соединения с базой данных
mysqli_close($conn);
?>