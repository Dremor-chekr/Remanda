<?php
session_start();
include '../php/connecting.php';



if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $productId = $_POST['product_id'];
  $quantity = $_POST['quantity'];
  $userId = $_SESSION['user_id'];

  $sql = "UPDATE Basket SET quantity = $quantity WHERE id = $productId AND id_user = $userId";
  mysqli_query($conn, $sql);

  header("Location: ../page/cart.php");
  exit();
}
?>
