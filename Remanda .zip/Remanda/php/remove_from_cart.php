<?php
session_start();
include '../php/connecting.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: ../page/login.php");
  exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $productId = $_POST['product_id'];
  $userId = $_SESSION['user_id'];

  $sql = "DELETE FROM Basket WHERE id = $productId AND id_user = $userId";
  mysqli_query($conn, $sql);

  header("Location: ../page/cart.php");
  exit();
}
?>
