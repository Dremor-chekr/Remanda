<?php
session_start();
include '../php/connecting.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userId = $_SESSION['user_id'];
    $address = $_POST['address'];

    // Получить товары из корзины
    $sql = "SELECT * FROM Basket WHERE id_user = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $cartItems = array();

    while ($row = $result->fetch_assoc()) {
        $cartItems[] = $row;
    }

    if (!empty($cartItems)) {
        // Начать транзакцию
        $conn->begin_transaction();

        try {
            // Добавить каждый товар как отдельную запись в таблицу Orders
            $insertOrderSql = "INSERT INTO Orders (user_id, product_id, name, img, price, quantity, total_price, address, order_date, status)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 'В обработке')";
            $stmt = $conn->prepare($insertOrderSql);

            foreach ($cartItems as $item) {
                $productId = $item['id']; // Используйте правильное поле для идентификации продукта
                $productName = $item['name'];
                $productImg = $item['img'];
                $productPrice = $item['price'];
                $quantity = $item['quantity'];
                $totalPrice = $productPrice * $quantity;

                // Добавить товар в Orders
                $stmt->bind_param("iisssiss", $userId, $productId, $productName, $productImg, $productPrice, $quantity, $totalPrice, $address);
                $stmt->execute();
            }

            // Очистить корзину
            $deleteBasketSql = "DELETE FROM Basket WHERE id_user = ?";
            $stmt = $conn->prepare($deleteBasketSql);
            $stmt->bind_param("i", $userId);
            $stmt->execute();

            // Завершить транзакцию
            $conn->commit();

            // Перенаправить пользователя после успешного оформления заказа
            header("Location: ../page/users.php");
            exit();
        } catch (Exception $e) {
            // В случае ошибки откатить транзакцию
            $conn->rollback();
            echo "Ошибка при выполнении заказа: " . $e->getMessage();
        }
    }
}
?>