<?php
session_start();
include '../php/connecting.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

$userId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productId = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);

    $sql = "UPDATE Basket SET quantity = ? WHERE id_user = ? AND id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $quantity, $userId, $productId);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'quantity' => $quantity]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
    
    $stmt->close();
}

mysqli_close($conn);
?>
