const loginButton = document.getElementById('login-button');

loginButton.addEventListener('click', () => {
  // Redirect to login page
  location.href = '../index.php';
});