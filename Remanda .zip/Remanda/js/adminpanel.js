document.getElementById('adminpanel').addEventListener('click', function() {
  window.location.href = "../page/admin.php";
});