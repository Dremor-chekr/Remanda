<?php


include './php/connecting.php'; 
  $sql = "SELECT * FROM Catalog LIMIT 3";
  $result = mysqli_query($conn, $sql);
  $products = array();
  while ($row = mysqli_fetch_assoc($result)){
    $products[] = $row;
  }
  mysqli_close($conn);

?>
  <!DOCTYPE html>
    <html lang="ru">
      <head>
        <meta charset="UTF-8">
          <title>HF Принтеры</title>
          <link rel="icon" href="../img/HF.png">
          <link rel="stylesheet" href="../css/stele.css">
          <link rel="stylesheet" type="text/css" href="/css/preloders.css">
          <link rel="stylesheet" href="../css/page_print.css">
          <link rel="stylesheet" type="text/css" href="../css/them.css">
        </meta>
      </head>
      <body>
        <div id="page-preloader" class="preloder">
            <div class="loader">

            </div>
        </div>
        <header>
          <div class="logo">
            <h1><img class="imglogo" src="/img/HF.png" alt="HF Принтеры">HF Принтеры</h1>
            <button class="theme-toggle-button" id="theme-toggle">Сменить тему</button>
            <button id="login-button">Войти</button>
            <button class="theme-toggle-button" style="top: 90px;"><a href="../page/cart.php">Корзина</a></button>
            <button id="adminpanel" class="theme-toggle-button" style="top: 130px;">Админка</a></button>
          </div>
          <nav class="Shapka">
            <ul>
              <li><a href="../index.php" class="nav-button">Главная</a></li>
              <li><a href="../page/katalog.php" class="nav-button">Каталог</a></li>
              <li><a href="../page/indormation.html" class="nav-button">О нас</a></li>
              <li><a href="../page/kontact.html" class="nav-button">Контакты</a></li>
              <li><a href="../page/users.php" class="nav-button">Личный кабинет</a></li>
            </ul>
          </nav>
        </header>
        <main id="main">
          <h2>Лучшие продаваемые принтеры</h2>
          <div>  
          <div id="products" >
            <?php foreach ($products as $product) {?>
              <div class="product" style="
              width: 250px;
              margin: 30px;
              background-color: #3d7c84;
              border: 1px solid #ddd;
              border-radius: 10px;
              padding: 20px;
              box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
                <h2><?php echo $product['name'];?></h2>
                  <a href="../page/product.php?id=<?php echo $product['id']; ?>">  
                    <img src="<?php echo $product['img']; ?>">
                  </a>
                <span class="price" style="color: white;"><?php echo $product['price'];?>₽</span>
                <form method="post" action="../php/add_to_cart.php"  style="background-color: #ffffff00">
                  <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                  <button type="submit" class="buy-button add-to-cart-button">Купить</button>
                </form>
              </div>
            <?php }?>
        </div>
            </main>
          </div>
            <script src="../js/preloder.js"></script>
      <footer>
        <div style="display: flex; justify-content: space-around;">
          <div style="width: 30%;">
            <h3>Компания</h3>
            <ul>
              <li><a href="../page/katalog.php">Каталог</a></li>
              <li><a href="../page/indormation.html">О нас</a></li>
              <li><a href="../page/kontact.html">Контакты</a></li>
            </ul>
          </div>
        <div style="width: 30%;">
          <div>
            <h3>Следите за нами</h3>
            <ul>
              <li><img src="/img/VK.png" alt="Иконка ВК"><a href="https://vk.com/feed">VK</a></li>
              <li><img src="/img/ТГ.png" alt="Иконка Телеграм"><a href="https://web.tlgrm.app/">Телеграм</a></li>
            </ul>
          </div>
        </div>
      </footer>
      <script src="../js/adminpanel.js"></script>
      <script src="../js/them.js"></script>
      <script src="../js/login_button.js"></script>
    </body>
</html>
